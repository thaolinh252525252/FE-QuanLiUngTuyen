import { useState } from "react";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";

function LookupPage() {
  const [phone, setPhone] = useState("");
  const [result, setResult] = useState(null);

  const handleLookup = () => {
    const mockResults = {
      "0912345678": "Pass",
      "0987654321": "Fail CV",
    };
    setResult(mockResults[phone] || "Không tìm thấy kết quả");
  };

  return (
    <>
      <Navbar />
      <div className="container">
        <h2 className="section-title">🔍 Tra cứu kết quả tuyển dụng</h2>
        <input
          type="text"
          placeholder="Nhập số điện thoại của bạn"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
          className="input"
        />
        <button onClick={handleLookup} className="btn-primary">Tra cứu</button>

        {result && <div className="result">{result}</div>}
      </div>
      <Footer />
    </>
  );
}

export default LookupPage;
