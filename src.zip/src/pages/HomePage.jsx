import { useState } from "react";
import { Link } from "react-router-dom";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";

function HomePage() {
  const jobList = [
    { id: 1, title: "Nhân viên Kinh doanh", location: "Hà Nội", experience: "3 năm", salary: "Thoả thuận" },
    { id: 2, title: "Lập trình viên Python", location: "Hồ Chí Minh", experience: "2 năm", salary: "15 - 20 triệu" },
  ];

  const [search, setSearch] = useState("");

  const filteredJobs = jobList.filter(job =>
    job.title.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <>
      <Navbar />
      <div className="container">
        <h2 className="section-title">Tìm kiếm việc làm</h2>
        <input
          type="text"
          placeholder="Nhập từ khóa tìm kiếm..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          style={{ padding: "12px", width: "100%", marginBottom: "20px", borderRadius: "8px", border: "1px solid #ccc" }}
        />

        <div className="job-grid">
          {filteredJobs.map((job) => (
            <div key={job.id} className="job-card">
              <h3>{job.title}</h3>
              <p><strong>Địa điểm:</strong> {job.location}</p>
              <p><strong>Kinh nghiệm:</strong> {job.experience}</p>
              <p><strong>Mức lương:</strong> {job.salary}</p>
              <Link to={`/job/${job.id}`} className="btn-primary">Xem chi tiết</Link>
            </div>
          ))}
        </div>
      </div>
      <Footer />
    </>
  );
}

export default HomePage;
