import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import AdminLayout from "../../components/AdminLayout";
import "../../Admin.css";

function AdminCandidateDetailPage() {
  const { id } = useParams();
  const [candidate, setCandidate] = useState(null);

  useEffect(() => {
    fetch(`http://localhost:8000/candidates/${id}`)
      .then(res => res.json())
      .then(data => setCandidate(data))
      .catch(err => console.error(err));
  }, [id]);

  if (!candidate) return <AdminLayout><p>Đang tải dữ liệu...</p></AdminLayout>;

  return (
    <AdminLayout>
      <div className="admin-card">
        <h2>📄 Chi Tiết Ứng Viên</h2>
        <p><strong>Họ tên:</strong> {candidate.name}</p>
        <p><strong>SĐT:</strong> {candidate.phone}</p>
        <p><strong>Vị trí:</strong> {candidate.position}</p>
        <p><strong>Trạng thái:</strong> {candidate.status}</p>
        <p><strong>Điểm đánh giá:</strong> {candidate.score || "Chưa đánh giá"}</p>
        <p><strong>Điểm mạnh:</strong> {candidate.strengths || "Chưa đánh giá"}</p>
        <p><strong>Điểm yếu:</strong> {candidate.weaknesses || "Chưa đánh giá"}</p>
        <a href={`/cv/${candidate.cvFile}`} target="_blank" rel="noopener noreferrer" className="btn btn-secondary">
          📎 Tải CV
        </a>
      </div>
    </AdminLayout>
  );
}

export default AdminCandidateDetailPage;
