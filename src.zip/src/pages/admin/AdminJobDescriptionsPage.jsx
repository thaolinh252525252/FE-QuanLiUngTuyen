import { useState } from "react";
import { useNavigate } from "react-router-dom";
import AdminLayout from "../../components/AdminLayout";
import "../../Admin.css";

function AdminJobDescriptionsPage() {
  const navigate = useNavigate();
  const allJobs = [
    { id: 1, title: "Nhân viên Kinh doanh", description: "Chăm sóc khách hàng, tư vấn sản phẩm", deadline: "30/06/2025" },
    { id: 2, title: "Lập trình viên Python", description: "Phát triển ứng dụng web", deadline: "15/07/2025" },
  ];

  const [search, setSearch] = useState("");

  const filteredJobs = allJobs.filter(job =>
    job.title.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <AdminLayout>
      <div className="admin-card">
        <h2>📄 Danh sách Mô tả Công việc</h2>
        <button className="btn btn-primary" onClick={() => navigate("/admin/job-descriptions/add")}>
          ➕ Thêm Mô tả Công việc
        </button>

        <input
          type="text"
          placeholder="Tìm kiếm vị trí..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          style={{ width: "100%", padding: "10px", borderRadius: "8px", marginBottom: "10px" }}
        />

        <table>
          <thead>
            <tr>
              <th>Vị trí</th>
              <th>Mô tả</th>
              <th>Hạn nộp</th>
              <th>Hành động</th>
            </tr>
          </thead>
          <tbody>
            {filteredJobs.map((job) => (
              <tr key={job.id}>
                <td>{job.title}</td>
                <td>{job.description}</td>
                <td>{job.deadline}</td>
                <td><button className="btn btn-secondary">Sửa</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </AdminLayout>
  );
}

export default AdminJobDescriptionsPage;
