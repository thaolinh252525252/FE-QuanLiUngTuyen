import { useState } from "react";
import AdminLayout from "../../components/AdminLayout";
import "../../Admin.css";

function AdminInterviewsPage() {
  const allInterviews = [
    { id: 1, candidate: "Nguyễn Văn A", date: "2025-05-30", time: "09:00", room: "Phòng 101" },
    { id: 2, candidate: "Trần Thị B", date: "2025-06-01", time: "14:00", room: "Phòng 202" },
  ];

  const [search, setSearch] = useState("");

  const filteredInterviews = allInterviews.filter(i =>
    i.candidate.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <AdminLayout>
      <div className="admin-card">
        <h2>📅 Lịch Phỏng vấn</h2>
        <input
          type="text"
          placeholder="Tìm kiếm ứng viên..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          style={{ width: "100%", padding: "10px", borderRadius: "8px", marginBottom: "10px" }}
        />

        <table>
          <thead>
            <tr>
              <th>Ứng viên</th>
              <th>Thời gian</th>
              <th>Địa điểm</th>
              <th>Hành động</th>
            </tr>
          </thead>
          <tbody>
            {filteredInterviews.map((i) => (
              <tr key={i.id}>
                <td>{i.candidate}</td>
                <td>{i.date} {i.time}</td>
                <td>{i.room}</td>
                <td><button className="btn btn-secondary">Sửa</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </AdminLayout>
  );
}

export default AdminInterviewsPage;
