import AdminLayout from "../../components/AdminLayout";
import "../../Admin.css";
import { PieChart, Pie, Cell, Legend, Tooltip, ResponsiveContainer } from "recharts";

function AdminReportsPage() {
  const data = [
    { name: "Ứng viên mới", value: 50 },
    { name: "Đã phỏng vấn", value: 20 },
    { name: "Trúng tuyển", value: 10 },
  ];

  const COLORS = ["#007bff", "#28a745", "#ffc107"];

  return (
    <AdminLayout>
      <div className="admin-card">
        <h2>📊 Báo cáo Thống kê</h2>
        <ResponsiveContainer width="100%" height={300}>
          <PieChart>
            <Pie data={data} dataKey="value" nameKey="name" outerRadius={100}>
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip />
            <Legend />
          </PieChart>
        </ResponsiveContainer>
      </div>
    </AdminLayout>
  );
}

export default AdminReportsPage;
