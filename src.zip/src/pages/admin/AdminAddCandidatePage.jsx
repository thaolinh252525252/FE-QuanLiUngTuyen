import { useState } from "react";
import AdminLayout from "../../components/AdminLayout";
import "../../Admin.css";

function AdminAddCandidatePage() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [position, setPosition] = useState("");
  const [cvFile, setCvFile] = useState(null);

  const handleSubmit = (e) => {
    e.preventDefault();

    const formData = new FormData();
    formData.append("name", name);
    formData.append("email", email);
    formData.append("phone", phone);
    formData.append("position", position);
    if (cvFile) {
      formData.append("cv", cvFile);
    }

    fetch("http://localhost:8000/candidates/", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name,
        email,
        phone,
        applied_position: position,
      }),
    })
      .then((res) => res.json())
      .then((data) => {
        alert("Thêm ứng viên thành công!");
        console.log(data);
      })
      .catch((err) => {
        console.error(err);
        alert("Thêm thất bại!");
      });
  };

  return (
    <AdminLayout>
      <div className="admin-card">
        <h2>➕ Thêm Ứng Viên Mới</h2>
        <form onSubmit={handleSubmit}>
          <input
            type="text"
            placeholder="Họ tên"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <input
            type="text"
            placeholder="Số điện thoại"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            required
          />
          <input
            type="text"
            placeholder="Vị trí ứng tuyển"
            value={position}
            onChange={(e) => setPosition(e.target.value)}
            required
          />
          <input
            type="file"
            onChange={(e) => setCvFile(e.target.files[0])}
          />
          <button type="submit" className="btn btn-primary">
            ✅ Thêm Ứng Viên
          </button>
        </form>
      </div>
    </AdminLayout>
  );
}

export default AdminAddCandidatePage;
