import AdminLayout from "../../components/AdminLayout";
import "../../Admin.css";

function AdminDashboardPage() {
  return (
    <AdminLayout>
      <div className="admin-card">
        <h2>📊 Thống kê tổng quan</h2>
        <p>✅ 25 Ứng viên mới</p>
        <p>✅ 10 Đã phỏng vấn</p>
        <p>✅ 15 Đã gửi kết quả</p>
      </div>
    </AdminLayout>
  );
}

export default AdminDashboardPage;
