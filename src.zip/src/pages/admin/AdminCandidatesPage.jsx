import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import AdminLayout from "../../components/AdminLayout";
import "../../Admin.css";

function AdminCandidatesPage() {
  const navigate = useNavigate();
  const [candidates, setCandidates] = useState([]);
  const [search, setSearch] = useState("");
  const [selectedIds, setSelectedIds] = useState([]);
  const [showScheduleForm, setShowScheduleForm] = useState(false);
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [location, setLocation] = useState("");

  // Gọi API lấy danh sách ứng viên từ backend
  useEffect(() => {
    fetch("http://localhost:8000/candidates/")
      .then(res => res.json())
      .then(data => setCandidates(data))
      .catch(err => console.error(err));
  }, []);

  const toggleSelect = (id) => {
    setSelectedIds((prev) => prev.includes(id) ? prev.filter(sid => sid !== id) : [...prev, id]);
  };

  const filteredCandidates = candidates.filter(c =>
    (c.ho_ten || "").toLowerCase().includes(search.toLowerCase()) ||
    (c.so_dien_thoai || "").includes(search)
  );

  const formatTrinhDoHocVan = (arr) => {
    if (!Array.isArray(arr)) return "-";
    return arr.map((e, i) =>
      `${i + 1}. ${e.truong || ""} - ${e.chuyen_nganh || ""} (${e.nam_tot_nghiep || ""})`
    ).join("\n");
  };

  const handleStatusChange = (id, newStatus) => {
    fetch(`http://localhost:8000/candidates/${id}/update-result?result=${encodeURIComponent(newStatus)}`, {
      method: "PATCH",
    })
      .then(res => res.json())
      .then(updated => {
        setCandidates(prev => prev.map(c => (c.id === id ? updated : c)));
        alert(`Đã gửi email kết quả "${newStatus}" cho ${updated.name}`);
      })
      .catch(err => console.error(err));
  };

  const handleSchedule = () => {
    if (selectedIds.length && date && time && location) {
      const selectedNames = candidates
        .filter(c => selectedIds.includes(c.id))
        .map(c => c.name)
        .join(", ");
      alert(`Đã đặt lịch cho: ${selectedNames} vào ${date} lúc ${time} tại ${location}`);
      setShowScheduleForm(false);
    } else {
      alert("Vui lòng chọn ứng viên và nhập đầy đủ thông tin");
    }
  };

  return (
    <AdminLayout>
      <div className="admin-card">
        <h2>🗂️ Quản lý Ứng viên</h2>

        {/* Nút điều hướng */}
        <div style={{ marginBottom: "10px" }}>
          <button className="btn btn-primary" onClick={() => navigate("/admin/candidates/add")}>
            ➕ Thêm Ứng Viên Mới
          </button>
          <button className="btn btn-secondary" onClick={() => setShowScheduleForm(!showScheduleForm)}>
            📅 Đặt lịch phỏng vấn
          </button>
        </div>

        {/* Tìm kiếm */}
        <input
          type="text"
          placeholder="Tìm kiếm theo tên hoặc SĐT..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          style={{ width: "100%", padding: "10px", borderRadius: "8px", marginBottom: "10px" }}
        />

        {/* Form Đặt lịch */}
        {showScheduleForm && (
          <div style={{ marginTop: "10px", background: "#f8f9fa", padding: "15px", borderRadius: "8px" }}>
            <h4>📅 Đặt lịch phỏng vấn</h4>
            <input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
            <input type="time" value={time} onChange={(e) => setTime(e.target.value)} />
            <input type="text" placeholder="Địa điểm" value={location} onChange={(e) => setLocation(e.target.value)} />
            <button className="btn btn-secondary" onClick={handleSchedule}>✅ Xác nhận đặt lịch</button>
          </div>
        )}

        {/* Bảng danh sách */}
        <div style={{ overflowX: "auto", maxWidth: "100%" }}>
          <table>
            <thead>
              <tr>
                <th></th>
                <th>Họ tên</th>
                <th>Email</th>
                <th>SĐT</th>
                <th>NTNS</th>
                <th>Quê quán</th>
                <th>Nơi ở</th>
                <th>Trình độ học vấn</th>
                <th>Kinh nghiệm</th>
                <th>Vị trí</th>
                <th>Kỹ năng khác</th>
                <th>Kết quả</th>
                <th>Cập nhật kết quả</th>
                <th>Chi tiết</th>
              </tr>
            </thead>
            <tbody>
              {filteredCandidates.map((c) => (
                <tr key={c.id}>
                  <td>
                    <input type="checkbox" checked={selectedIds.includes(c.id)} onChange={() => toggleSelect(c.id)} />
                  </td>
                  <td>{c.name}</td>
                  <td>{c.email || "-"}</td>
                  <td>{c.phone}</td>
                  <td>{c.birth_date || "-"}</td>
                  <td>{c.hometown || "-"}</td>
                  <td>{c.address || "-"}</td>
                  <td>{c.education_level || "-"}</td>
                  <td>{c.work_experience || "-"}</td>
                  <td>{c.applied_position || "-"}</td>
                  <td>{c.other_skills || "-"}</td>
                  <td>{c.result || "Chưa đánh giá"}</td>
                  <td>
                    <select
                      defaultValue=""
                      onChange={(e) => handleStatusChange(c.id, e.target.value)}
                      style={{ padding: "8px", borderRadius: "8px" }}
                    >
                      <option value="">-- Chọn kết quả --</option>
                      <option value="Pass">Pass</option>
                      <option value="Fail CV">Fail CV</option>
                      <option value="Fail Interview">Fail Interview</option>
                    </select>
                  </td>
                  <td>
                    <button className="btn btn-primary" onClick={() => navigate(`/admin/candidates/${c.id}`)}>
                      Xem chi tiết
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </AdminLayout>
  );
}

export default AdminCandidatesPage;
