import AdminLayout from "../../components/AdminLayout";
import "../../Admin.css";

function AdminUsersPage() {
  const users = [
    { name: "admin", role: "Quản trị viên" },
    { name: "hr01", role: "Nhân sự" },
    { name: "viewer01", role: "Người xem" },
  ];

  const roles = ["Quản trị viên", "Nhân sự", "Người xem"];

  const handleChangeRole = (userName, newRole) => {
    alert(`Đã phân quyền ${newRole} cho ${userName}`);
    // TODO: Gửi API cập nhật phân quyền
  };

  return (
    <AdminLayout>
      <div className="admin-card">
        <h2>🛡️ Quản lý Người dùng & Phân quyền</h2>
        <table>
          <thead>
            <tr>
              <th>Tên người dùng</th>
              <th>Vai trò hiện tại</th>
              <th>Thay đổi vai trò</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user, idx) => (
              <tr key={idx}>
                <td>{user.name}</td>
                <td>{user.role}</td>
                <td>
                  <select
                    defaultValue={user.role}
                    onChange={(e) => handleChangeRole(user.name, e.target.value)}
                    style={{ padding: "8px", borderRadius: "8px" }}
                  >
                    {roles.map((role, rIdx) => (
                      <option key={rIdx} value={role}>{role}</option>
                    ))}
                  </select>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <button className="btn btn-primary">➕ Thêm Người dùng</button>
      </div>
    </AdminLayout>
  );
}

export default AdminUsersPage;
