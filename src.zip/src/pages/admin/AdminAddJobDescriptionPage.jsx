import { useState } from "react";
import AdminLayout from "../../components/AdminLayout";
import "../../Admin.css";

function AdminAddJobDescriptionPage() {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [deadline, setDeadline] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    alert(`Đã thêm: ${title} - ${description} - ${deadline}`);
    // TODO: Gửi dữ liệu lên server
  };

  return (
    <AdminLayout>
      <div className="admin-card">
        <h2>➕ Thêm Mô tả Công việc</h2>
        <form onSubmit={handleSubmit}>
          <input type="text" placeholder="Vị trí" value={title} onChange={(e) => setTitle(e.target.value)} required />
          <textarea placeholder="Mô tả công việc" value={description} onChange={(e) => setDescription(e.target.value)} required style={{ width: "100%", padding: "10px", borderRadius: "8px", minHeight: "100px", marginBottom: "10px" }}></textarea>
          <input type="date" value={deadline} onChange={(e) => setDeadline(e.target.value)} required />
          <button type="submit" className="btn btn-primary">✅ Thêm Mô tả</button>
        </form>
      </div>
    </AdminLayout>
  );
}

export default AdminAddJobDescriptionPage;
