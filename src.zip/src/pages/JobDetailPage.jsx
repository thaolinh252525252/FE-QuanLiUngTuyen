import { Link, useParams } from "react-router-dom";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";

function JobDetailPage() {
  const { jobId } = useParams();

  const jobDetails = {
    1: {
      title: "Nhân viên Kinh doanh",
      salary: "Thoả thuận",
      location: "Hà Nội",
      experience: "3 năm",
      deadline: "22/05/2025",
      description: "Chăm sóc khách hàng, tư vấn sản phẩm...",
      requirements: "Kỹ năng giao tiếp, đàm phán, ưu tiên kinh nghiệm Sales.",
    },
    2: {
      title: "Lập trình viên Python",
      salary: "15 - 20 triệu",
      location: "Hồ Chí Minh",
      experience: "2 năm",
      deadline: "22/06/2025",
      description: "Phát triển API với Python, FastAPI...",
      requirements: "Thành thạo Python, có kinh nghiệm với FastAPI/Django.",
    },
  };

  const job = jobDetails[jobId];

  if (!job) {
    return <div className="container">Không tìm thấy công việc</div>;
  }

  return (
    <>
      <Navbar />
      <div className="container">
        <h2 className="section-title">{job.title}</h2>
        <p><strong>Mức lương:</strong> {job.salary}</p>
        <p><strong>Địa điểm:</strong> {job.location}</p>
        <p><strong>Kinh nghiệm:</strong> {job.experience}</p>
        <p><strong>Hạn nộp hồ sơ:</strong> {job.deadline}</p>

        <h3>Chi tiết tin tuyển dụng</h3>
        <p><strong>Mô tả công việc:</strong> {job.description}</p>
        <p><strong>Yêu cầu:</strong> {job.requirements}</p>

        <p style={{ marginTop: "20px", backgroundColor: "#f8f9fa", padding: "15px", borderRadius: "8px" }}>
          <strong>Cách ứng tuyển:</strong> Gửi email về <a href="mailto:hr@congty.com">hr@congty.com</a> kèm CV và tiêu đề email: [Vị trí] - [Họ tên]
        </p>

        <Link to="/" className="btn-secondary">⬅️ Quay lại danh sách</Link>
      </div>
      <Footer />
    </>
  );
}

export default JobDetailPage;
