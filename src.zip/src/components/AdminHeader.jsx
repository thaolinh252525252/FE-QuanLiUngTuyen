function AdminHeader() {
  return (
    <div className="admin-header">
      <h1>Hệ thống quản lý tuyển dụng</h1>
    </div>
  );
}

export default AdminHeader;
