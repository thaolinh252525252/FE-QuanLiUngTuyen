import AdminSidebar from "./AdminSidebar";
import "../App.css";

function AdminLayout({ children }) {
  return (
    <div className="admin-layout">
      <header className="admin-header">
        <div>🎯 Quản trị hệ thống tuyển dụng</div>
        <div>👤 admin | 🔓 Logout</div>
      </header>
      <div className="admin-body">
        <AdminSidebar />
        <main className="admin-content">{children}</main>
      </div>
    </div>
  );
}

export default AdminLayout;
