function Footer() {
  return (
    <footer className="footer">
      <div className="container">
        © 2025 Công ty ABC | Liên hệ: hr@congty.com
      </div>
    </footer>
  );
}

export default Footer;
