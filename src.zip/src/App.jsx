import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import HomePage from "./pages/HomePage";
import JobDetailPage from "./pages/JobDetailPage";
import LookupPage from "./pages/LookupPage";
import AdminJobDescriptionsPage from "./pages/admin/AdminJobDescriptionsPage";
import AdminReportsPage from "./pages/admin/AdminReportsPage";
import AdminUsersPage from "./pages/admin/AdminUsersPage";
import AdminDashboardPage from "./pages/admin/AdminDashboardPage";
import AdminCandidatesPage from "./pages/admin/AdminCandidatesPage";
import AdminInterviewsPage from "./pages/admin/AdminInterviewsPage";
import AdminAddCandidatePage from "./pages/admin/AdminAddCandidatePage";
import AdminCandidateDetailPage from "./pages/admin/AdminCandidateDetailPage";
import AdminAddJobDescriptionPage from "./pages/admin/AdminAddJobDescriptionPage";
import AdminLoginPage from "./pages/admin/AdminLoginPage";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/job/:jobId" element={<JobDetailPage />} />
        <Route path="/tra-cuu" element={<LookupPage />} />
        <Route path="/admin" element={<AdminLoginPage />} />
        <Route path="/admin/dashboard" element={<AdminDashboardPage />} />
        <Route path="/admin/candidates" element={<AdminCandidatesPage />} />
        <Route path="/admin/interviews" element={<AdminInterviewsPage />} />
        <Route path="/admin/job-descriptions" element={<AdminJobDescriptionsPage />} />
        <Route path="/admin/reports" element={<AdminReportsPage />} />
        <Route path="/admin/users" element={<AdminUsersPage />} />
        <Route path="/admin/candidates/add" element={<AdminAddCandidatePage />} />
        <Route path="/admin/job-descriptions/add" element={<AdminAddJobDescriptionPage />} />
<Route path="/admin/candidates/:id" element={<AdminCandidateDetailPage />} />
      </Routes>
    </Router>
  );
}

export default App;
